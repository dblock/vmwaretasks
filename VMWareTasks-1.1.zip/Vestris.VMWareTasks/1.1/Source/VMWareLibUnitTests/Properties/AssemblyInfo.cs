﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareLibUnitTests")]
[assembly: Guid("8e2c23e6-c1ec-42fc-a96d-f0d3c3d52551")]
