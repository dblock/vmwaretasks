using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Vestris.VMWareLibUnitTests
{
    [TestFixture]
    public class VMWareJobTests
    {
    }
}
