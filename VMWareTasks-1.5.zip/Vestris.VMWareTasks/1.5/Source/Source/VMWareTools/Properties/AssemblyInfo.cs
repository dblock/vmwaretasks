﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareTools")]
[assembly: AssemblyDescription("VMWareTasks Tools Library")]
[assembly: Guid("5f61a9e4-ca20-4f74-9ef2-080d8e5b1302")]
[assembly: ComVisible(false)]
