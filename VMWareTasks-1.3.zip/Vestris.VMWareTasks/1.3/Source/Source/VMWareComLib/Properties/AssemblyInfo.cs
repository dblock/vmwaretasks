﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareComLib")]
[assembly: AssemblyDescription("VMWareTasks COM Interop Library")]
[assembly: ComVisible(true)]
[assembly: Guid("0b67aa5a-bd1c-4ebe-8ab7-b8c5df711e0d")]
