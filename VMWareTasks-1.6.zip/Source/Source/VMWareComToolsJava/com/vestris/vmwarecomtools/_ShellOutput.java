package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{AC162259-AC96-3A6B-A657-91030EB49A19}")
public interface _ShellOutput extends Com4jObject {
}
