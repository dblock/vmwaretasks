package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{F43F1731-54F3-320A-9F70-4EC03AAF7E6B}")
public interface _GuestOS extends Com4jObject {
}
