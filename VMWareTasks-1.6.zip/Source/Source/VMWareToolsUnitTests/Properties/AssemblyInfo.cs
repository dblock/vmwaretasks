﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareToolsUnitTests")]
[assembly: AssemblyDescription("VMWareTasks Tools Library Unit Tests")]
[assembly: ComVisible(false)]
