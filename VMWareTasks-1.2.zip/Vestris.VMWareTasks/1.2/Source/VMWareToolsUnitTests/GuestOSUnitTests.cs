﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using Vestris.VMWareLib;
using Vestris.VMWareLib.Tools;
using Vestris.VMWareLibUnitTests;
using System.IO;

namespace Vestris.VMWareToolsUnitTests
{
    [TestFixture]
    public class GuestOSUnitTests : VMWareTestSetup
    {
    }
}
