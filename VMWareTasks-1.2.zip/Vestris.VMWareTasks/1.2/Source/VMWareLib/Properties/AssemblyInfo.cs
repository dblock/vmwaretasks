﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareLib")]
[assembly: Guid("e102c7ef-224a-4a61-ba79-454ad6d92e97")]
