﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareToolsSamples")]
[assembly: AssemblyDescription("VMWareTasks Tools Library Samples")]
[assembly: Guid("769723fb-8f9b-40b0-ba16-f2a567cf2f53")]
[assembly: ComVisible(false)]
