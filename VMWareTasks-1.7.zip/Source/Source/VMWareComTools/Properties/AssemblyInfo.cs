﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareComTools")]
[assembly: AssemblyDescription("VMWareTasks Tools COM Interop Library")]
[assembly: ComVisible(true)]
[assembly: Guid("3489194b-bc32-40d8-982f-898545ddde1d")]
