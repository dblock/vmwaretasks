﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareLibMSBuildTasks")]
[assembly: AssemblyDescription("VMWareTasks MSBuild Library")]
[assembly: Guid("03069325-0041-44ab-807a-de0e73ba55d1")]
[assembly: ComVisible(false)]