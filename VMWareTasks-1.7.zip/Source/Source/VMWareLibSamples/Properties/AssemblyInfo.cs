﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VMWareLibSamples")]
[assembly: AssemblyDescription("VMWareTasks Automation Library Samples")]
[assembly: Guid("2c39b3fe-fbf5-458b-ac07-9c1630a1d14c")]
[assembly: ComVisible(false)]
