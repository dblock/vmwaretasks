package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{504BC958-8E3E-4DB0-A64C-E7410E1CDCCC}")
public interface IVariableIndexer extends Com4jObject {
    @VTID(7)
    @DefaultMethod
    java.lang.String item(
        java.lang.String name);

}
