package com.vestris.vmwarecomtools  ;

import com4j.*;

@IID("{75B66EC2-0BE4-3B27-A1A7-D97DF9C1840B}")
public interface _VMWareSharedFolder extends Com4jObject {
}
